export default function Home(){

return (
<main>
<nav style={{padding:30,background:'#fff'}}>
<h2>TalentOS Health™</h2>
</nav>

<section style={{
minHeight:'80vh',
display:'flex',
alignItems:'center',
justifyContent:'center',
background:'linear-gradient(135deg,#0B1F3A,#00A8E8)',
color:'white',
textAlign:'center'
}}>

<div>
<h1 style={{fontSize:55}}>
The AI Operating System<br/>
for Healthcare Talent
</h1>

<p>
Connecting pharmacy, life science students and healthcare employers.
</p>

<button style={{
padding:15,
borderRadius:10,
border:0
}}>
Start Career
</button>

</div>

</section>

</main>
)

}
