import './globals.css';

export const metadata = {
 title: 'TalentOS Health™',
 description: 'AI Operating System for Healthcare Talent'
};

export default function RootLayout({children}:{children:React.ReactNode}){
 return (
  <html lang="en">
   <body>{children}</body>
  </html>
 );
}
