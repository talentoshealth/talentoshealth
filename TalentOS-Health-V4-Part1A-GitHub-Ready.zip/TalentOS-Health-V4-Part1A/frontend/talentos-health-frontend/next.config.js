module.exports={
 reactStrictMode:true
}
